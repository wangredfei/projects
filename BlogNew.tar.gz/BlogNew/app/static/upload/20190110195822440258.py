a='a'
print(a >'b' or 'c')
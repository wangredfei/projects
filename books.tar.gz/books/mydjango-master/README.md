# mydjango
the code about django
